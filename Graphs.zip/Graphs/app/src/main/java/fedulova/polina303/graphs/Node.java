package fedulova.polina303.graphs;

public class Node {
    public float x, y;

    public Node(float x, float y){
        this.x = x;
        this.y = y;
    }
}
